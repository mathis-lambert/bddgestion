<?php
include_once('include/head.php');
include_once('include/sidenav.php');
?>

<div class="container">
    <div class="content">
        <h1>Bienvenue sur ce site de gestion d'une base de données</h1>
    </div>
</div>
<?php
include_once('include/footer.php');
