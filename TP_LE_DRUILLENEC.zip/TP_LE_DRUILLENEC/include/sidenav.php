<section id="sidenav">
    <br>
    <h1>MENU</h1>
    <nav>
        <ul>
            <li><a href="http://bdd.gestion/TP_LE_DRUILLENEC/index.php" id="index">Accueil</a></li>
            <li><a href="http://bdd.gestion/TP_LE_DRUILLENEC/afficherTable.php" id="display">Afficher Table</a></li>
            <li><a href="http://bdd.gestion/TP_LE_DRUILLENEC/ajouterInfo.php" id="add">Ajouter Informations</a></li>
            <li><a href="http://bdd.gestion/TP_LE_DRUILLENEC/modifierTable.php" id="update">Modifier Table</a></li>
            <li><a href="http://bdd.gestion/TP_LE_DRUILLENEC/supprimer.php" id="delete">Supprimer</a></li>
        </ul>
    </nav>
</section>