<script src="assets/app/app.js"></script>
</body>

</html>